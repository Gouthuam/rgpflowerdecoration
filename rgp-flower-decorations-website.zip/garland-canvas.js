// Robust 2D Canvas Renderer for RGP Garland Customizer

function initGarlandCanvas(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    const ctx = canvas.getContext('2d');
    
    function render(config) {
        if (!config) return;
        const width = canvas.width || 420;
        const height = canvas.height || 520;
        
        ctx.clearRect(0, 0, width, height);
        
        // 1. Dark Velvet Background with Soft Gold Glow
        const bgGrad = ctx.createRadialGradient(width/2, height/2, 40, width/2, height/2, width * 0.8);
        bgGrad.addColorStop(0, '#1c1522');
        bgGrad.addColorStop(0.7, '#100c16');
        bgGrad.addColorStop(1, '#07050a');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);
        
        // 2. Decorative Gold Arch Frame
        ctx.save();
        ctx.strokeStyle = 'rgba(212, 175, 55, 0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(width/2, height * 0.45, Math.min(width, height) * 0.4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
        
        // 3. Render Garlands based on style
        const isPair = config.style !== 'grand_royal';
        
        try {
            if (isPair) {
                // Left Garland (Bride)
                drawSingleGarland(ctx, width * 0.3, height * 0.1, height * 0.72, config, "Bride Maalai (மணமகள்)", 0.95);
                // Right Garland (Groom)
                drawSingleGarland(ctx, width * 0.7, height * 0.1, height * 0.72, config, "Groom Maalai (மணமகன்)", 0.95);
            } else {
                // Single Grand Royal Garland
                drawSingleGarland(ctx, width * 0.5, height * 0.08, height * 0.76, config, "Grand Royal Muhurtham (பிரம்மாண்ட மாலை)", 1.2);
            }
        } catch(e) {
            console.error("Canvas Render Error:", e);
        }
    }
    
    function drawSingleGarland(ctx, cx, startY, endY, config, label, scale = 1.0) {
        ctx.save();
        
        const curveWidth = 55 * scale;
        const garlandLength = Math.max(100, endY - startY);
        const bottomY = startY + garlandLength * 0.72;
        
        // Gold Hanging Top Ring
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 3 * scale;
        ctx.beginPath();
        ctx.arc(cx, startY - 10, Math.max(2, 8 * scale), 0, Math.PI * 2);
        ctx.stroke();
        
        // Draw Curved Strands (Left & Right halves)
        const steps = 30;
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            const currentY = startY + t * (bottomY - startY);
            const xOffset = Math.sin(t * Math.PI) * (curveWidth * 0.45);
            
            const lx = cx - curveWidth + xOffset;
            const rx = cx + curveWidth - xOffset;
            
            // Draw left flower cluster
            drawFloralNode(ctx, lx, currentY, config, t, scale);
            // Draw right flower cluster
            drawFloralNode(ctx, rx, currentY, config, t, scale);
        }
        
        // Draw Gold Zari Crown Junction (Mogappu)
        const junctionY = bottomY;
        drawZariCrown(ctx, cx, junctionY, Math.max(5, 24 * scale));
        
        // Draw Centerpiece (Lotus / Rose / Orchid)
        if (config.accent === 'lotus') {
            drawLotusBud(ctx, cx, junctionY, Math.max(5, 18 * scale));
        } else if (config.accent === 'orchid') {
            drawOrchid(ctx, cx, junctionY, Math.max(5, 16 * scale));
        } else {
            drawRosePetalCluster(ctx, cx, junctionY, Math.max(5, 18 * scale));
        }
        
        // Pendant Tassel (Thongu)
        const pendantY = junctionY + 38 * scale;
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 2 * scale;
        ctx.beginPath();
        ctx.moveTo(cx, junctionY + 12);
        ctx.lineTo(cx, pendantY);
        ctx.stroke();
        
        if (config.pendant === 'lotus_cluster') {
            drawLotusBud(ctx, cx - 10 * scale, pendantY, Math.max(3, 12 * scale));
            drawLotusBud(ctx, cx + 10 * scale, pendantY, Math.max(3, 12 * scale));
            drawLotusBud(ctx, cx, pendantY + 12 * scale, Math.max(4, 15 * scale));
        } else if (config.pendant === 'rose_ball') {
            drawRosePetalCluster(ctx, cx, pendantY + 8 * scale, Math.max(4, 14 * scale));
        } else {
            drawJasmineTassel(ctx, cx, pendantY + 8 * scale, Math.max(3, 10 * scale));
        }
        
        // Label Badge
        ctx.fillStyle = '#fbe8a6';
        ctx.font = 'bold 12px "Mukta Malar", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, cx, endY + 22 * scale);
        
        ctx.restore();
    }
    
    function drawFloralNode(ctx, x, y, config, t, scale) {
        let baseColor = '#ffffff'; // Jasmine White
        let strokeColor = '#e5e7e9';
        
        if (config.base === 'redrose') {
            baseColor = '#c70039';
            strokeColor = '#900c3f';
        } else if (config.base === 'dutchrose') {
            baseColor = '#800020';
            strokeColor = '#d4af37';
        } else if (config.base === 'tuberose') {
            baseColor = '#f9f9f9';
            strokeColor = '#d5d8dc';
        }
        
        // Main Flower Puff
        const radius = Math.max(3, (14 + Math.sin(t * Math.PI * 8) * 3) * scale);
        ctx.save();
        ctx.fillStyle = baseColor;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
        
        // Periodical Accent Insertions (every few steps)
        const stepIndex = Math.floor(t * 12);
        if (stepIndex % 3 === 0) {
            if (config.accent === 'lotus') {
                drawLotusBud(ctx, x, y, Math.max(3, 9 * scale));
            } else if (config.accent === 'orchid') {
                drawOrchid(ctx, x, y, Math.max(3, 8 * scale));
            } else if (config.accent === 'zari') {
                drawZariCrown(ctx, x, y, Math.max(3, 9 * scale));
            }
        }
    }
    
    function drawLotusBud(ctx, x, y, radius) {
        if (radius <= 0) return;
        ctx.save();
        ctx.fillStyle = '#ff69b4'; // Vibrant Pink
        ctx.strokeStyle = '#c71585';
        ctx.lineWidth = 1.5;
        
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        // Inner Petal Layer
        ctx.fillStyle = '#ffb6c1';
        ctx.beginPath();
        ctx.arc(x, y - radius * 0.2, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
    
    function drawRosePetalCluster(ctx, x, y, radius) {
        if (radius <= 0) return;
        ctx.save();
        ctx.fillStyle = '#b7094c';
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.fillStyle = '#ff4d6d';
        ctx.beginPath();
        ctx.arc(x - radius * 0.2, y - radius * 0.2, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
    
    function drawOrchid(ctx, x, y, radius) {
        if (radius <= 0) return;
        ctx.save();
        ctx.fillStyle = '#8a2be2';
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#da70d6';
        ctx.beginPath();
        ctx.arc(x, y, radius * 0.4, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
    
    function drawZariCrown(ctx, x, y, radius) {
        if (radius <= 0) return;
        ctx.save();
        const goldGrad = ctx.createLinearGradient(x - radius, y - radius, x + radius, y + radius);
        goldGrad.addColorStop(0, '#ffe57f');
        goldGrad.addColorStop(0.5, '#d4af37');
        goldGrad.addColorStop(1, '#996515');
        ctx.fillStyle = goldGrad;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
    
    function drawJasmineTassel(ctx, x, y, radius) {
        if (radius <= 0) return;
        ctx.fillStyle = '#ffffff';
        for(let i = -1; i <= 1; i++) {
            ctx.beginPath();
            ctx.arc(x + i * 5, y + Math.abs(i) * 3, radius * 0.5, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    return { render };
}
