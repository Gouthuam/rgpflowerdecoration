// Main Application Script for RGP Flower Decorations

let currentLang = 'en';
let garlandCanvas = null;
let currentConfig = {
    base: 'jasmine',
    accent: 'lotus',
    style: 'twin_pair',
    length: '3.5',
    pendant: 'lotus_cluster'
};

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Garland Canvas Visualizer
    garlandCanvas = initGarlandCanvas('garlandCanvas');
    
    // 2. Populate Dropdowns
    populateConfigDropdowns();
    
    // 3. Render Calendar & Market Ticker
    renderCalendar();
    renderMarketTicker();
    
    // 4. Initial Canvas Render
    updateGarlandConfig();
    
    // 5. Apply Initial Language
    switchLanguage('en');
    
    // 6. Load Admin Dashboard Data
    loadAdminInquiries();
    loadAdminFlowerRates();
});

// Language Switcher Function
function switchLanguage(lang) {
    currentLang = lang;
    
    // Update active class on buttons
    document.getElementById('btnLangEn').classList.toggle('active', lang === 'en');
    document.getElementById('btnLangTa').classList.toggle('active', lang === 'ta');
    
    // Update DOM text elements
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });
    
    // Re-populate dropdowns with localized names
    populateConfigDropdowns();
    renderCalendar();
}

// Populate Garland Configurator Select Elements
function populateConfigDropdowns() {
    const isTa = currentLang === 'ta';
    
    // Base Flowers
    const selectBase = document.getElementById('selectBaseFlower');
    selectBase.innerHTML = flowerPricing.baseFlowers.map(f => 
        `<option value="${f.id}" ${f.id === currentConfig.base ? 'selected' : ''}>${isTa ? f.nameTa : f.nameEn}</option>`
    ).join('');
    
    // Accent Flowers
    const selectAccent = document.getElementById('selectAccentFlower');
    selectAccent.innerHTML = flowerPricing.accentFlowers.map(f => 
        `<option value="${f.id}" ${f.id === currentConfig.accent ? 'selected' : ''}>${isTa ? f.nameTa : f.nameEn} (+₹${f.addPrice})</option>`
    ).join('');
    
    // Styles
    const selectStyle = document.getElementById('selectStyle');
    selectStyle.innerHTML = flowerPricing.styles.map(s => 
        `<option value="${s.id}" ${s.id === currentConfig.style ? 'selected' : ''}>${s.nameEn}</option>`
    ).join('');
    
    // Lengths
    const selectLength = document.getElementById('selectLength');
    selectLength.innerHTML = flowerPricing.lengths.map(l => 
        `<option value="${l.id}" ${l.id === currentConfig.length ? 'selected' : ''}>${l.nameEn}</option>`
    ).join('');
    
    // Pendants
    const selectPendant = document.getElementById('selectPendant');
    selectPendant.innerHTML = flowerPricing.pendants.map(p => 
        `<option value="${p.id}" ${p.id === currentConfig.pendant ? 'selected' : ''}>${p.nameEn} ${p.addPrice > 0 ? '(+₹'+p.addPrice+')' : ''}</option>`
    ).join('');
}

// Toggle Visualizer View Mode (Photo vs Canvas)
function setVisualizerView(mode) {
    const photoBox = document.getElementById('photoContainer');
    const canvasBox = document.getElementById('canvasContainerBox');
    const btnPhoto = document.getElementById('btnViewPhoto');
    const btnCanvas = document.getElementById('btnViewCanvas');
    
    if (!photoBox || !canvasBox || !btnPhoto || !btnCanvas) return;
    
    if (mode === 'photo') {
        photoBox.style.display = 'block';
        canvasBox.style.display = 'none';
        btnPhoto.classList.add('active');
        btnCanvas.classList.remove('active');
    } else {
        photoBox.style.display = 'none';
        canvasBox.style.display = 'flex';
        btnCanvas.classList.add('active');
        btnPhoto.classList.remove('active');
        if (garlandCanvas && typeof garlandCanvas.render === 'function') {
            garlandCanvas.render(currentConfig);
        }
    }
}

// Update Garland Config from UI Select Inputs
function updateGarlandConfig() {
    const baseEl = document.getElementById('selectBaseFlower');
    const accentEl = document.getElementById('selectAccentFlower');
    const styleEl = document.getElementById('selectStyle');
    const lengthEl = document.getElementById('selectLength');
    const pendantEl = document.getElementById('selectPendant');

    if (!baseEl || !accentEl || !styleEl || !lengthEl || !pendantEl) return;

    currentConfig.base = baseEl.value;
    currentConfig.accent = accentEl.value;
    currentConfig.style = styleEl.value;
    currentConfig.length = lengthEl.value;
    currentConfig.pendant = pendantEl.value;
    
    // Calculate Estimated Price
    const baseObj = flowerPricing.baseFlowers.find(b => b.id === currentConfig.base) || flowerPricing.baseFlowers[0];
    const accentObj = flowerPricing.accentFlowers.find(a => a.id === currentConfig.accent) || flowerPricing.accentFlowers[0];
    const styleObj = flowerPricing.styles.find(s => s.id === currentConfig.style) || flowerPricing.styles[0];
    const lengthObj = flowerPricing.lengths.find(l => l.id === currentConfig.length) || flowerPricing.lengths[0];
    const pendantObj = flowerPricing.pendants.find(p => p.id === currentConfig.pendant) || flowerPricing.pendants[0];
    
    let totalEst = (styleObj.baseCost * lengthObj.multiplier * baseObj.priceMultiplier) + accentObj.addPrice + pendantObj.addPrice;
    totalEst = Math.round(totalEst / 100) * 100; // Round to nearest 100
    
    const displayPriceEl = document.getElementById('displayEstPrice');
    if (displayPriceEl) {
        displayPriceEl.textContent = `₹${totalEst.toLocaleString('en-IN')}`;
    }
    
    // Dynamic Real HD Photo Showcase
    const photoImg = document.getElementById('mainRealGarlandPhoto');
    const photoTitle = document.getElementById('realPhotoTitle');
    if (photoImg && photoTitle) {
        if (currentConfig.base === 'redrose' || currentConfig.base === 'dutchrose') {
            photoImg.src = 'assets/images/redrose_gold_pair.jpg';
            photoTitle.textContent = `${baseObj.nameEn} with Gold Zari & Jasmine Accent`;
        } else if (currentConfig.accent === 'orchid') {
            photoImg.src = 'assets/images/orchid_tuberose_pair.jpg';
            photoTitle.textContent = `${accentObj.nameEn} & ${baseObj.nameEn} Subamugurtham Pair`;
        } else if (currentConfig.style === 'grand_royal') {
            photoImg.src = 'assets/images/temple_decor.jpg';
            photoTitle.textContent = `Grand Royal Muhurtham - ${baseObj.nameEn}`;
        } else {
            photoImg.src = 'assets/images/jasmine_lotus_pair.jpg';
            photoTitle.textContent = `${baseObj.nameEn} & ${accentObj.nameEn} Subamugurtham Pair`;
        }
    }
    
    // Re-draw Canvas safely
    if (garlandCanvas && typeof garlandCanvas.render === 'function') {
        garlandCanvas.render(currentConfig);
    }
}

// Subamugurtham Calendar Renderer
function renderCalendar() {
    const container = document.getElementById('calendarContainer');
    if (!container) return;
    
    container.innerHTML = subamugurthamDates.map(item => {
        const statusText = item.status === 'available' ? (currentLang === 'ta' ? 'முன்பதிவு செய்யப்படலாம்' : 'Available') :
                          item.status === 'fast-filling' ? (currentLang === 'ta' ? 'விரைவில் முடிகிறது' : 'Fast Filling') :
                          (currentLang === 'ta' ? 'முன்பதிவு முடிந்தது' : 'Fully Booked');
        
        return `
            <div class="cal-card" onclick="selectCalendarDate('${item.date}')">
                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <div>
                        <div class="cal-date-num">${item.date}</div>
                        <div style="font-size: 0.85rem; color: var(--text-muted);">${item.dayName}</div>
                    </div>
                    <div style="text-align: right;">
                        <div class="cal-tamil-month">${item.tamilMonth}</div>
                        <div style="font-size: 0.8rem; color: var(--gold-light);">நட்சத்திரம்: ${item.star}</div>
                    </div>
                </div>
                <div class="status-badge status-${item.status}">${statusText}</div>
            </div>
        `;
    }).join('');
}

// Handle Calendar Date Selection
function selectCalendarDate(dateStr) {
    document.getElementById('inputDate').value = dateStr;
    const bookingSec = document.getElementById('booking');
    if (bookingSec) {
        bookingSec.scrollIntoView({ behavior: 'smooth' });
    }
}

// Send Garland WhatsApp Order with Custom Configuration
function sendGarlandWhatsAppOrder() {
    const estPrice = document.getElementById('displayEstPrice').textContent;
    const baseObj = flowerPricing.baseFlowers.find(b => b.id === currentConfig.base);
    const accentObj = flowerPricing.accentFlowers.find(a => a.id === currentConfig.accent);
    const styleObj = flowerPricing.styles.find(s => s.id === currentConfig.style);
    
    const msg = `*RGP FLOWER DECORATIONS - CUSTOM GARLAND INQUIRY*\n` +
                `----------------------------------------\n` +
                `🌸 *Style:* ${styleObj.nameEn}\n` +
                `🌿 *Base Flower:* ${baseObj.nameEn}\n` +
                `🌺 *Accent Flower:* ${accentObj.nameEn}\n` +
                `📏 *Length:* ${currentConfig.length} Feet\n` +
                `💰 *Est. Price:* ${estPrice}\n` +
                `----------------------------------------\n` +
                `Hi RGP Flower Decorations, I want to confirm availability for this custom design!`;
                
    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/9345695469?text=${encoded}`, '_blank');
}

// Quick Select Service from Cards
function quickSelectService(serviceKey) {
    const inputType = document.getElementById('inputType');
    if (inputType) {
        if (serviceKey === 'serv1' || serviceKey === 'serv4') {
            inputType.value = 'Reception Garlands (ரிசப்ஷன் மாலைகள்)';
        } else if (serviceKey === 'serv2' || serviceKey === 'serv3') {
            inputType.value = 'Wedding Garlands (திருமண / சுபமுகூர்த் மாலைகள்)';
        } else if (serviceKey === 'serv5') {
            inputType.value = 'Mandapam Decorations (மண்டப அலங்காரங்கள்)';
        } else if (serviceKey === 'serv6') {
            inputType.value = 'Swami Moolavar & Uthsavar Alangaram (சுவாமி மூலவர் & உற்சவர் அலங்காரம்)';
        }
    }
    const bookingSec = document.getElementById('booking');
    if (bookingSec) {
        bookingSec.scrollIntoView({ behavior: 'smooth' });
    }
}

// Booking Form Submit Handler
function handleBookingSubmit(event) {
    event.preventDefault();
    
    const name = document.getElementById('inputName').value;
    const phone = document.getElementById('inputPhone').value;
    const date = document.getElementById('inputDate').value;
    const type = document.getElementById('inputType').value;
    const venue = document.getElementById('inputVenue').value;
    const budget = document.getElementById('inputBudget').value || 'Flexible';
    const notes = document.getElementById('inputNotes').value || 'None';
    
    const bookingData = { name, phone, date, type, venue, budget, notes, timestamp: new Date().toLocaleString() };
    
    // Save to localStorage for Admin Portal
    let inquiries = JSON.parse(localStorage.getItem('rgp_inquiries') || '[]');
    inquiries.unshift(bookingData);
    localStorage.setItem('rgp_inquiries', JSON.stringify(inquiries));
    loadAdminInquiries();
    
    // Format WhatsApp Message
    const msg = `*RGP FLOWER DECORATIONS - EVENT BOOKING REQUEST*\n` +
                `----------------------------------------\n` +
                `👤 *Customer Name:* ${name}\n` +
                `📞 *Phone:* ${phone}\n` +
                `📅 *Event Date:* ${date}\n` +
                `🎉 *Event Type:* ${type}\n` +
                `📍 *Venue/City:* ${venue}\n` +
                `💰 *Budget:* ${budget}\n` +
                `📝 *Notes:* ${notes}\n` +
                `----------------------------------------\n` +
                `Please contact me to confirm our booking!`;
                
    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/9345695469?text=${encoded}`, '_blank');
}

// Generate Printable PDF / Window Quote
function generatePrintableQuote() {
    const name = document.getElementById('inputName').value || 'Valued Customer';
    const phone = document.getElementById('inputPhone').value || '9345695469';
    const date = document.getElementById('inputDate').value || new Date().toISOString().split('T')[0];
    const type = document.getElementById('inputType').value;
    const venue = document.getElementById('inputVenue').value || 'Venue';
    const estPrice = document.getElementById('displayEstPrice').textContent;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>RGP Flower Decorations - Official Quote</title>
            <style>
                body { font-family: sans-serif; padding: 40px; color: #111; line-height: 1.5; }
                .header { text-align: center; border-bottom: 2px solid #d4af37; padding-bottom: 20px; margin-bottom: 30px; }
                .brand { font-size: 24px; font-weight: bold; color: #996515; }
                .tagline { font-size: 14px; color: #555; margin-top: 5px; }
                .details-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                .details-table td { padding: 10px; border: 1px solid #ddd; }
                .details-table td.label { font-weight: bold; background: #f9f9f9; width: 35%; }
                .total-box { background: #fff8dc; border: 1.5px solid #d4af37; padding: 20px; text-align: right; font-size: 18px; font-weight: bold; }
                .footer-text { text-align: center; margin-top: 50px; font-size: 12px; color: #777; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="brand">RGP FLOWER DECORATIONS</div>
                <div class="tagline">மனம் கவரும் மாலைகள், மறக்க முடியாத தருணங்கள், RGP-யின் அன்பான சேவை.</div>
                <div>Contact Helpline: +91 9345695469</div>
            </div>

            <h2>Official Floral Decoration Estimate</h2>
            <table class="details-table">
                <tr><td class="label">Customer Name</td><td>${name}</td></tr>
                <tr><td class="label">Phone Number</td><td>${phone}</td></tr>
                <tr><td class="label">Event Date</td><td>${date}</td></tr>
                <tr><td class="label">Event Type</td><td>${type}</td></tr>
                <tr><td class="label">Venue / Location</td><td>${venue}</td></tr>
            </table>

            <div class="total-box">
                Estimated Price: <span style="color: #996515;">${estPrice}</span>
            </div>

            <div class="footer-text">
                Thank you for choosing RGP Flower Decorations. For direct confirmation, call or WhatsApp 9345695469.
            </div>
            <script>window.print();</script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// Toggle Admin Business Modal
function toggleAdminModal() {
    const modal = document.getElementById('adminModal');
    modal.classList.toggle('active');
}

// Load Admin Dashboard Saved Inquiries
function loadAdminInquiries() {
    const listContainer = document.getElementById('adminInquiriesList');
    const countDisplay = document.getElementById('adminInquiryCount');
    if (!listContainer || !countDisplay) return;
    
    let inquiries = JSON.parse(localStorage.getItem('rgp_inquiries') || '[]');
    countDisplay.textContent = inquiries.length;
    
    if (inquiries.length === 0) {
        listContainer.innerHTML = `<div style="color: var(--text-muted); text-align: center; padding: 20px;">No offline bookings logged yet. Submissions via form appear here!</div>`;
        return;
    }
    
    listContainer.innerHTML = inquiries.map((inq, idx) => `
        <div style="background: rgba(255,255,255,0.04); border-left: 3px solid var(--gold-primary); padding: 12px; border-radius: 6px; margin-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; font-weight: bold; color: var(--gold-light);">
                <span>${inq.name} (${inq.phone})</span>
                <span style="color: var(--lotus-pink);">${inq.date}</span>
            </div>
            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">
                ${inq.type} @ ${inq.venue} | Budget: ${inq.budget}
            </div>
            <div style="font-size: 0.8rem; color: #888; margin-top: 2px;">Logged: ${inq.timestamp}</div>
        </div>
    `).join('');
}

// Clear Admin Logs
function clearAdminLogs() {
    if (confirm('Clear all saved local inquiries?')) {
        localStorage.removeItem('rgp_inquiries');
        loadAdminInquiries();
    }
}

// Render Live Govt Market Ticker Bar
function renderMarketTicker() {
    const tickerContainer = document.getElementById('marketTickerContent');
    if (!tickerContainer) return;

    let savedRates = JSON.parse(localStorage.getItem('rgp_daily_rates') || 'null');
    let rateData = savedRates || dailyFlowerRates.rates;

    tickerContainer.innerHTML = rateData.map(r => {
        const arrow = r.trend === 'up' ? '▲' : r.trend === 'down' ? '▼' : '➖';
        const trendClass = `trend-${r.trend}`;
        return `
            <div class="ticker-item">
                <span>🌸 <strong>${r.nameEn}:</strong> ₹${r.rate}/${r.unit}</span>
                <span class="${trendClass}">${arrow}</span>
            </div>
        `;
    }).join(' <span style="color: rgba(212,175,55,0.3);">|</span> ');
}

// Load Admin Dashboard Flower Rate Editor
function loadAdminFlowerRates() {
    const grid = document.getElementById('adminRatesEditorGrid');
    if (!grid) return;

    let savedRates = JSON.parse(localStorage.getItem('rgp_daily_rates') || 'null');
    let ratesList = savedRates || dailyFlowerRates.rates;

    grid.innerHTML = ratesList.map(r => `
        <div style="background: rgba(255,255,255,0.04); padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(212,175,55,0.2);">
            <div style="font-size: 0.8rem; font-weight: bold; color: var(--gold-light);">${r.nameEn} (${r.unit})</div>
            <div style="display: flex; gap: 8px; margin-top: 4px;">
                <input type="number" id="rate_${r.id}" value="${r.rate}" class="form-input" style="padding: 4px 8px; font-size: 0.85rem;" placeholder="Rate ₹">
                <select id="trend_${r.id}" class="control-select" style="padding: 4px 8px; font-size: 0.8rem;">
                    <option value="up" ${r.trend === 'up' ? 'selected' : ''}>▲ Up</option>
                    <option value="stable" ${r.trend === 'stable' ? 'selected' : ''}>➖ Stable</option>
                    <option value="down" ${r.trend === 'down' ? 'selected' : ''}>▼ Down</option>
                </select>
            </div>
        </div>
    `).join('');
}

// Save Admin Flower Rates
function saveAdminFlowerRates() {
    let savedRates = JSON.parse(localStorage.getItem('rgp_daily_rates') || 'null');
    let ratesList = savedRates || dailyFlowerRates.rates;

    const updatedRates = ratesList.map(r => {
        const inputEl = document.getElementById(`rate_${r.id}`);
        const trendEl = document.getElementById(`trend_${r.id}`);
        return {
            ...r,
            rate: inputEl ? parseInt(inputEl.value) || r.rate : r.rate,
            trend: trendEl ? trendEl.value : r.trend
        };
    });

    localStorage.setItem('rgp_daily_rates', JSON.stringify(updatedRates));
    renderMarketTicker();
    alert("Today's Government Flower Market Rates updated successfully!");
}
