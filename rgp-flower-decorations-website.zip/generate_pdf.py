# Python Script to Generate Professional PDF Documentation for RGP Flower Decorations

import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

def build_pdf(filename="RGP_Flower_Decorations_User_Guide.pdf"):
    doc = SimpleDocTemplate(
        filename,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )
    
    styles = getSampleStyleSheet()
    
    # Custom Gold / Obsidian Color Palette
    primary_gold = colors.HexColor("#996515")
    dark_gold = colors.HexColor("#6b4408")
    accent_pink = colors.HexColor("#c70039")
    text_dark = colors.HexColor("#1a1a1a")
    bg_light = colors.HexColor("#faf6ee")
    
    # Custom Paragraph Styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=24,
        leading=28,
        textColor=primary_gold,
        alignment=1, # Center
        spaceAfter=8
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=12,
        leading=16,
        textColor=accent_pink,
        alignment=1,
        spaceAfter=20
    )
    
    h1_style = ParagraphStyle(
        'SectionH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=20,
        textColor=dark_gold,
        spaceBefore=15,
        spaceAfter=8
    )

    h2_style = ParagraphStyle(
        'SectionH2',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=primary_gold,
        spaceBefore=10,
        spaceAfter=6
    )

    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=text_dark,
        spaceAfter=8
    )

    bullet_style = ParagraphStyle(
        'BulletDark',
        parent=body_style,
        leftIndent=15,
        bulletIndent=5,
        spaceAfter=4
    )

    story = []
    
    # Header Banner Box
    story.append(Paragraph("RGP FLOWER DECORATIONS", title_style))
    story.append(Paragraph("மனம் கவரும் மாலைகள், மறக்க முடியாத தருணங்கள், RGP-யின் அன்பான சேவை.", subtitle_style))
    story.append(Paragraph("<b>Helpline:</b> +91 9345695469 | <b>Document:</b> Platform User & Deployment Guide v1.0", ParagraphStyle('SubHeader', parent=body_style, alignment=1)))
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=2, color=primary_gold, spaceBefore=5, spaceAfter=15))
    
    # 1. Executive Summary
    story.append(Paragraph("1. Executive Business & Platform Overview", h1_style))
    story.append(Paragraph("<b>RGP Flower Decorations</b> platform is a digital web solution built for booking fresh flower garlands, wedding venue decorations, and temple deity arrangements. The platform empowers customers to view designs, customize garlands interactively, check auspicious wedding dates, calculate pricing, and instantly place orders via WhatsApp directly to <b>9345695469</b>.", body_style))
    
    # Services Table
    services_data = [
        [Paragraph("<b>Service Category</b>", body_style), Paragraph("<b>Tamil Title</b>", body_style), Paragraph("<b>Description & Features</b>", body_style)],
        [Paragraph("Reception Garlands", body_style), Paragraph("ரிசப்ஷன் மாலைகள்", body_style), Paragraph("Vibrant rose & orchid sets crafted for reception events.", body_style)],
        [Paragraph("Subamugurtham Garlands", body_style), Paragraph("சுபமுகூர்த் மாலைகள்", body_style), Paragraph("Traditional lotus and fragrant jasmine pairs for wedding rituals.", body_style)],
        [Paragraph("Wedding Garlands", body_style), Paragraph("திருமண மாலைகள்", body_style), Paragraph("Bride & groom twin garland pairs with golden zari thread work.", body_style)],
        [Paragraph("Welcome Garlands", body_style), Paragraph("வரவேற்பு மாலைகள்", body_style), Paragraph("Fresh jasmine & rose garlands for VIP guests and traditional welcome.", body_style)],
        [Paragraph("Mandapam Decor", body_style), Paragraph("மண்டப அலங்காரங்கள்", body_style), Paragraph("Royal stage backdrops, entrance arches, floral pillars, and oil lamps.", body_style)],
        [Paragraph("Swami Alangaram", body_style), Paragraph("சுவாமி அலங்காரம்", body_style), Paragraph("Sacred flower garlands for temple deities (Moolavar & Uthsavar).", body_style)]
    ]
    
    t_services = Table(services_data, colWidths=[130, 110, 290])
    t_services.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), bg_light),
        ('GRID', (0,0), (-1,-1), 0.5, primary_gold),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_services)
    story.append(Spacer(1, 15))
    
    # 2. Key Platform Features & Modules
    story.append(Paragraph("2. Key Platform Features & User Guide", h1_style))
    story.append(Paragraph("• <b>Bilingual Language Switcher:</b> Click the <i>English / தமிழ்</i> pill button in the top navigation bar to toggle the entire application text.", bullet_style))
    story.append(Paragraph("• <b>Interactive Garland Customizer:</b> Select base flowers (Jasmine, Tube Rose, Red Rose, Dutch Rose), accent flowers (Lotus, Orchid, Gold Zari), style, length, and pendants. The 2D Canvas visually updates in real time with automated pricing.", bullet_style))
    story.append(Paragraph("• <b>Subamugurtham Calendar:</b> View upcoming auspicious Tamil wedding dates with real-time status badges (<i>Available</i>, <i>Fast Filling</i>, <i>Booked</i>). Clicking a date auto-populates the booking form.", bullet_style))
    story.append(Paragraph("• <b>1-Click WhatsApp Ordering:</b> Generates pre-formatted WhatsApp text containing order parameters, venue details, and estimated price, sent directly to <b>9345695469</b>.", bullet_style))
    story.append(Paragraph("• <b>Printable PDF Estimate Generator:</b> Customers or shop staff can generate a formatted quotation document with official branding.", bullet_style))
    story.append(Paragraph("• <b>Owner Business Dashboard:</b> Click 'Admin' in the navigation bar to inspect saved customer inquiries and log offline bookings.", bullet_style))
    
    story.append(Spacer(1, 15))
    
    # 3. Hosting & Internet Access Guide (24/7 Access Anywhere)
    story.append(Paragraph("3. Hosting & 24/7 Worldwide Internet Access", h1_style))
    story.append(Paragraph("To host this website on the internet so that customers anywhere in the world can access it 24/7, follow any of the 3 free deployment methods below:", body_style))
    
    hosting_data = [
        [Paragraph("<b>Hosting Platform</b>", body_style), Paragraph("<b>Ease of Setup</b>", body_style), Paragraph("<b>Step-by-Step Instructions</b>", body_style)],
        [
            Paragraph("<b>Netlify Drop (Recommended)</b>", body_style),
            Paragraph("⭐ Very Easy (30 Secs)", body_style),
            Paragraph("1. Go to <font color='#0066cc'><u>app.netlify.com/drop</u></font><br/>2. Drag & drop the project folder <code>rgp-flower-decorations</code>.<br/>3. Netlify will instantly generate a live URL (e.g. <code>https://rgp-flowers.netlify.app</code>).", body_style)
        ],
        [
            Paragraph("<b>Vercel</b>", body_style),
            Paragraph("⭐ Very Easy (1 Min)", body_style),
            Paragraph("1. Go to <font color='#0066cc'><u>vercel.com</u></font> and sign up.<br/>2. Import folder or connect repository.<br/>3. Click Deploy. Your site is live instantly with free SSL!", body_style)
        ],
        [
            Paragraph("<b>GitHub Pages</b>", body_style),
            Paragraph("⭐⭐ Easy", body_style),
            Paragraph("1. Push project files to a GitHub repository.<br/>2. Go to Repo Settings -> Pages -> Select 'main' branch.<br/>3. Site will be published at <code>https://username.github.io/rgp-flower-decorations</code>.", body_style)
        ]
    ]
    
    t_hosting = Table(hosting_data, colWidths=[120, 110, 300])
    t_hosting.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), bg_light),
        ('GRID', (0,0), (-1,-1), 0.5, primary_gold),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_hosting)
    story.append(Spacer(1, 20))
    
    # Custom Domain Note
    story.append(Paragraph("<b>Connecting Custom Domain Name:</b> Once published on Netlify or Vercel, you can link a custom domain such as <code>www.rgpflowerdecorations.com</code> directly from domain settings.", ParagraphStyle('Note', parent=body_style, backColor=bg_light, borderPadding=8)))
    
    story.append(Spacer(1, 25))
    story.append(HRFlowable(width="100%", thickness=1, color=primary_gold, spaceBefore=5, spaceAfter=10))
    story.append(Paragraph("Report Generated for RGP Flower Decorations | Helpline: +91 9345695469", ParagraphStyle('Footer', parent=body_style, alignment=1, fontSize=8, textColor=colors.gray)))
    
    doc.build(story)
    print(f"PDF successfully generated: {filename}")

if __name__ == '__main__':
    build_pdf()
