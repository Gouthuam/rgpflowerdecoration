// Data & i18n Translations for RGP Flower Decorations

const translations = {
    en: {
        brandName: "RGP FLOWER DECORATIONS",
        tagline: "Captivating garlands, unforgettable moments, warm service from RGP.",
        taglineTamil: "மனம் கவரும் மாலைகள், மறக்க முடியாத தருணங்கள், RGP-யின் அன்பான சேவை.",
        phone: "9345695469",
        phoneFormatted: "+91 9345695469",
        navHome: "Home",
        navServices: "Services",
        navConfigurator: "Garland Visualizer",
        navCalendar: "Subamugurtham Dates",
        navGallery: "Gallery",
        navContact: "Book Now",
        navAdmin: "Owner Admin",
        heroTitle: "Artisanal Fresh Flower Garlands & Event Decoration",
        heroSubtitle: "Handcrafted Subamugurtham wedding maalaigal, grand mandapam decor, and divine temple swami alangaram.",
        btnCustomize: "Design Custom Garland",
        btnBookDate: "Check Wedding Availability",
        btnCallNow: "Call Us Immediately",
        btnWhatsApp: "Order via WhatsApp",
        
        // Highlights
        highFreshTitle: "100% Fresh Flowers",
        highFreshDesc: "Sourced daily directly from Madurai & Nilakottai flower markets.",
        highAuspiciousTitle: "Subamugurtham Specialist",
        highAuspiciousDesc: "Dedicated auspicious timing floral delivery for weddings & rituals.",
        highCustomTitle: "Custom Artisanal Designs",
        highCustomDesc: "Personalized lotus, rose, jasmine & gold zari garland patterns.",
        
        // Services
        servicesTitle: "Our Signature Services",
        servicesSubtitle: "Premium floral craftsmanship for all your auspicious occasions",
        serv1: "Reception Garlands",
        serv1Tamil: "ரிசப்ஷன் மாலைகள்",
        serv1Desc: "Sleek, lightweight, vibrant rose & orchid garland sets for wedding receptions.",
        
        serv2: "Subamugurtham Garlands",
        serv2Tamil: "சுபமுகூர்த் மாலைகள்",
        serv2Desc: "Grand, traditional lotus and fragrant jasmine pairs crafted for Muhurtham rituals.",
        
        serv3: "Wedding Garlands",
        serv3Tamil: "திருமண மாலைகள்",
        serv3Desc: "Exquisite bride & groom twin garland pairs with golden zari thread work.",
        
        serv4: "Welcome Garlands",
        serv4Tamil: "வரவேற்பு மாலைகள்",
        serv4Desc: "Fragrant jasmine and rose garlands for VIP guests and traditional welcomes.",
        
        serv5: "Mandapam Decorations",
        serv5Tamil: "மண்டப அலங்காரங்கள்",
        serv5Desc: "Royal stage backdrops, entrance arches, floral pillars, and kuthu vilakku decor.",
        
        serv6: "Swami Moolavar & Uthsavar Alangaram",
        serv6Tamil: "சுவாமி மூலவர் & உற்சவர் அலங்காரம்",
        serv6Desc: "Sacred, divine flower garlands and crown arrangements for temple deities.",
        
        // Visualizer
        visTitle: "Interactive Garland Visualizer & Price Estimator",
        visSubtitle: "Customize your dream wedding garland pair and calculate real-time estimated pricing.",
        visBaseFlower: "Base Flower",
        visAccentFlower: "Accent Flower",
        visStyle: "Garland Style",
        visLength: "Garland Length",
        visPendant: "Pendant (Thongu)",
        visEstPrice: "Estimated Price (Pair)",
        visBookThis: "Order This Design on WhatsApp",
        
        // Calendar
        calTitle: "Subamugurtham Wedding Calendar 2026-2027",
        calSubtitle: "Reserve your floral decorations early for auspicious Tamil wedding dates.",
        calSelectDate: "Selected Event Date",
        calAvailable: "Available for Booking",
        calFastFilling: "Fast Filling - Few Slots",
        calBooked: "Fully Booked",
        
        // Form
        formTitle: "Book Your Event Decoration",
        formSubtitle: "Fill out the form below or chat directly on WhatsApp for instant confirmation.",
        formName: "Your Full Name",
        formPhone: "Phone / WhatsApp Number",
        formDate: "Event Date",
        formType: "Event Type",
        formVenue: "Venue / City / Mandapam Name",
        formBudget: "Budget Range (₹)",
        formNotes: "Special Flower Requirements / Notes",
        formSubmit: "Send Booking Request via WhatsApp",
        formPrintQuote: "Generate Printable Quote PDF",
        
        // Footer
        footerAddress: "RGP Flower Decorations, Main Road, Tamil Nadu",
        footerTag: "Crafting floral memories for unforgettable moments."
    },
    ta: {
        brandName: "RGP FLOWER DECORATIONS",
        tagline: "மனம் கவரும் மாலைகள், மறக்க முடியாத தருணங்கள், RGP-யின் அன்பான சேவை.",
        taglineTamil: "மனம் கவரும் மாலைகள், மறக்க முடியாத தருணங்கள், RGP-யின் அன்பான சேவை.",
        phone: "9345695469",
        phoneFormatted: "+91 9345695469",
        navHome: "முகப்பு",
        navServices: "சேவைகள்",
        navConfigurator: "மாலை வடிவமைப்பு",
        navCalendar: "சுபமுகூர்த்த நாட்கள்",
        navGallery: "புகைப்படங்கள்",
        navContact: "முன்பதிவு செய்ய",
        navAdmin: "நிர்வாகி பகுதி",
        heroTitle: "அழகிய புது மலர் மாலைகள் & மண்டப அலங்காரங்கள்",
        heroSubtitle: "கைவினை சுபமுகூர்த்த திருமண மாலைகள், பிரம்மாண்ட மண்டப அலங்காரம் மற்றும் தெய்வ சுவாமி அலங்காரங்கள்.",
        btnCustomize: "உங்கள் மாலையை வடிவமையுங்கள்",
        btnBookDate: "சுபமுகூர்த்த நாள் பார்க்க",
        btnCallNow: "உடனே அழைக்க",
        btnWhatsApp: "வாட்ஸ்அப்பில் ஆர்டர் செய்ய",
        
        // Highlights
        highFreshTitle: "100% புது மலர்கள்",
        highFreshDesc: "மதுரை & நிலக்கோட்டை மலர் சந்தைகளில் இருந்து தினமும் பெறப்படும் புது மலர்கள்.",
        highAuspiciousTitle: "சுபமுகூர்த்த நிபுணர்",
        highAuspiciousDesc: "திருமணம் மற்றும் விசேஷங்களுக்கு சரியான நேரத்தில் மலர் டெலிவரி.",
        highCustomTitle: "விருப்ப வடிவமைப்பு",
        highCustomDesc: "தாமரை, ரோஜா, மல்லிகை & தங்க ஜரி மாலை டிசைன்கள்.",
        
        // Services
        servicesTitle: "எங்கள் சிறப்பு சேவைகள்",
        servicesSubtitle: "உங்கள் சுப நிகழ்வுகளுக்கான சிறந்த மலர் அலங்காரங்கள்",
        serv1: "ரிசப்ஷன் மாலைகள்",
        serv1Tamil: "ரிசப்ஷன் மாலைகள்",
        serv1Desc: "வரவேற்பு விழாக்களுக்கான இலகுவான மற்றும் வண்ணமயமான ரோஜா, ஆர்ச்சிட் மாலைகள்.",
        
        serv2: "சுபமுகூர்த் மாலைகள்",
        serv2Tamil: "சுபமுகூர்த் மாலைகள்",
        serv2Desc: "முகூர்த்த சடங்குகளுக்காக பிரத்யேகமாக தயார் செய்யப்படும் தாமரை & மல்லிகை மாலைகள்.",
        
        serv3: "திருமண மாலைகள்",
        serv3Tamil: "திருமண மாலைகள்",
        serv3Desc: "மணமகன்-மணமகளுக்கான தங்க ஜரி வேலைப்பாடுகளுடன் கூடிய ஜோடி மாலைகள்.",
        
        serv4: "வரவேற்பு மாலைகள்",
        serv4Tamil: "வரவேற்பு மாலைகள்",
        serv4Desc: "முக்கிய விருந்தினர்களுக்கான நறுமணமிக்க மல்லிகை மற்றும் ரோஜா மாலைகள்.",
        
        serv5: "மண்டப அலங்காரங்கள்",
        serv5Tamil: "மண்டப அலங்காரங்கள்",
        serv5Desc: "ராஜரீக மேடை பின்னணிகள், நுழைவு வளைவுகள், மலர் தூண்கள் மற்றும் குத்துவிளக்கு அலங்காரம்.",
        
        serv6: "சுவாமி மூலவர் & உற்சவர் அலங்காரம்",
        serv6Tamil: "சுவாமி மூலவர் & உற்சவர் அலங்காரம்",
        serv6Desc: "கோவில் தெய்வங்களுக்கான தெய்வீக மலர் மாலைகள் மற்றும் கிரீட அலங்காரங்கள்.",
        
        // Visualizer
        visTitle: "மாலை வடிவமைப்பு & விலை கணிப்பான்",
        visSubtitle: "உங்கள் விருப்ப மாலை ஜோடியை வடிவமைத்து உடனடி தோராய விலையை தெரிந்துகொள்ளுங்கள்.",
        visBaseFlower: "முதன்மை மலர்",
        visAccentFlower: "கூடுதல் மலர் (அலங்காரம்)",
        visStyle: "மாலை மாடல்",
        visLength: "மாலை நீளம்",
        visPendant: "தொங்கு (தாமரை / ரோஜா பந்து)",
        visEstPrice: "தோராய விலை (ஜோடி)",
        visBookThis: "இந்த மாடலை வாட்ஸ்அப்பில் ஆர்டர் செய்ய",
        
        // Calendar
        calTitle: "சுபமுகூர்த்த திருமண நாட்கள் 2026-2027",
        calSubtitle: "சுபமுகூர்த்த நாட்களுக்கு முன்கூட்டியே உங்கள் மலர் அலங்காரங்களை பதிவு செய்யுங்கள்.",
        calSelectDate: "தேர்ந்தெடுக்கப்பட்ட தேதி",
        calAvailable: "முன்பதிவு செய்யப்படலாம்",
        calFastFilling: "விரைவில் முடிகிறது",
        calBooked: "முன்பதிவு முடிந்தது",
        
        // Form
        formTitle: "மலர் அலங்காரம் முன்பதிவு செய்ய",
        formSubtitle: "கீழே உள்ள படிவத்தை பூர்த்தி செய்யவும் அல்லது வாட்ஸ்அப்பில் நேரடியாக தொடர்பு கொள்ளவும்.",
        formName: "உங்கள் பெயர்",
        formPhone: "தொலைபேசி / வாட்ஸ்அப் எண்",
        formDate: "நிகழ்ச்சி தேதி",
        formType: "நிகழ்ச்சி வகை",
        formVenue: "மண்டபம் / ஊர் பெயர்",
        formBudget: "பட்ஜெட் (₹)",
        formNotes: "சிறப்பு தேவைகள் / குறிப்புகள்",
        formSubmit: "வாட்ஸ்அப்பில் பதிவு அனுப்புக",
        formPrintQuote: "விலைப்பட்டியல் PDF உருவாக்க",
        
        // Footer
        footerAddress: "RGP ஃபிளவர் டெக்கரேஷன்ஸ், மெயின் ரோடு, தமிழ்நாடு",
        footerTag: "மறக்க முடியாத தருணங்களுக்கு மனம் கவரும் மாலைகள்."
    }
};

const subamugurthamDates = [
    { date: "2026-10-18", tamilMonth: "ஐப்பசி 01", dayName: "Sunday", star: "Rohini", status: "available" },
    { date: "2026-10-25", tamilMonth: "ஐப்பசி 08", dayName: "Sunday", star: "Uthiratathi", status: "fast-filling" },
    { date: "2026-11-01", tamilMonth: "ஐப்பசி 15", dayName: "Sunday", star: "Pushyam", status: "available" },
    { date: "2026-11-08", tamilMonth: "ஐப்பசி 22", dayName: "Sunday", star: "Mirugaseerisham", status: "booked" },
    { date: "2026-11-15", tamilMonth: "ஐப்பசி 29", dayName: "Sunday", star: "Rohini", status: "fast-filling" },
    { date: "2026-11-22", tamilMonth: "கார்த்திகை 06", dayName: "Sunday", star: "Uthiradam", status: "available" },
    { date: "2026-12-04", tamilMonth: "கார்த்திகை 18", dayName: "Friday", star: "Swathi", status: "available" },
    { date: "2026-12-10", tamilMonth: "கார்த்திகை 24", dayName: "Thursday", star: "Avittam", status: "available" },
    { date: "2027-01-24", tamilMonth: "தை 10", dayName: "Sunday", star: "Rohini", status: "available" },
    { date: "2027-02-07", tamilMonth: "தை 24", dayName: "Sunday", star: "Uthiradam", status: "available" },
    { date: "2027-02-14", tamilMonth: "மாசி 02", dayName: "Sunday", star: "Rohini", status: "fast-filling" }
];

const flowerPricing = {
    baseFlowers: [
        { id: "jasmine", nameEn: "Pure Madurai Jasmine (மல்லிகை)", nameTa: "மதுரை மல்லிகை", priceMultiplier: 1.0 },
        { id: "tuberose", nameEn: "Scented Tube Rose (சம்பங்கி)", nameTa: "சம்பங்கி", priceMultiplier: 0.85 },
        { id: "redrose", nameEn: "Red Rose Petals (சிவப்பு ரோஜா)", nameTa: "சிவப்பு ரோஜா இதழ்கள்", priceMultiplier: 1.15 },
        { id: "dutchrose", nameEn: "Dutch Rose Petal Velvet (டச்சு ரோஜா)", nameTa: "டச்சு ரோஜா இதழ்கள்", priceMultiplier: 1.35 }
    ],
    accentFlowers: [
        { id: "lotus", nameEn: "Pink Lotus Buds (தாமரை)", nameTa: "தாமரை மொட்டுகள்", addPrice: 1200 },
        { id: "orchid", nameEn: "Purple Orchids (ஆர்ச்சிட்)", nameTa: "ஆர்ச்சிட் பூக்கள்", addPrice: 1500 },
        { id: "zari", nameEn: "Golden Zari Work (தங்க ஜரி)", nameTa: "தங்க ஜரி வேலைப்பாடு", addPrice: 800 },
        { id: "babybreath", nameEn: "Baby's Breath & White Chrysanthemum", nameTa: "வெள்ளை சாமந்தி & பேபி பிரீத்", addPrice: 700 }
    ],
    styles: [
        { id: "twin_pair", nameEn: "Groom & Bride Twin Garland Pair (ஜோடி மாலை)", baseCost: 4500 },
        { id: "grand_royal", nameEn: "Royal Heavy Grand Muhurtham Pair (பிரம்மாண்ட முகூர்த்த மாலை)", baseCost: 7500 },
        { id: "sleek_modern", nameEn: "Sleek Modern V-Shape Reception Pair (மாடர்ன் ரிசப்ஷன் மாலை)", baseCost: 3800 }
    ],
    lengths: [
        { id: "3.5", nameEn: "Standard (3.5 Feet / 1.05m)", multiplier: 1.0 },
        { id: "4.5", nameEn: "Grand Heavy (4.5 Feet / 1.37m)", multiplier: 1.3 }
    ],
    pendants: [
        { id: "lotus_cluster", nameEn: "Lotus Cluster Thongu (தாமரை கொத்து தொங்கு)", addPrice: 800 },
        { id: "rose_ball", nameEn: "Red Rose Ball & Gold Beads (ரோஜா பந்து தொங்கு)", addPrice: 600 },
        { id: "none", nameEn: "Standard Flower Tassel (சாதாரண பூ தொங்கு)", addPrice: 0 }
    ]
};

const dailyFlowerRates = {
    lastUpdated: "Today 08:00 AM (Madurai & Nilakottai Govt Flower Mandi Rate)",
    rates: [
        { id: "jasmine", nameEn: "Madurai Jasmine (மல்லிகை)", unit: "1 Kg", rate: 850, trend: "up" },
        { id: "lotus", nameEn: "Lotus Buds (தாமரை)", unit: "100 Pcs", rate: 1200, trend: "stable" },
        { id: "redrose", nameEn: "Red Rose (சிவப்பு ரோஜா)", unit: "1 Kg", rate: 240, trend: "up" },
        { id: "tuberose", nameEn: "Tube Rose (சம்பங்கி)", unit: "1 Kg", rate: 180, trend: "down" },
        { id: "mullai", nameEn: "Mullai Flower (முல்லை)", unit: "1 Kg", rate: 700, trend: "stable" },
        { id: "sevvanthi", nameEn: "Chrysanthemum (செவ்வந்தி)", unit: "1 Kg", rate: 160, trend: "stable" }
    ]
};
